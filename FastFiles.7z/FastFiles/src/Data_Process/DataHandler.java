package Data_Process;


import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.*;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

/**
 *
 * @author Ashan Nuwantha
 */
public class DataHandler implements Serializable{
    private static String getString;
    private static int getInteger;
    private static char getchar[];
    private final String passCharat []={"#","A","B","C","D","E","F","H","I","J"};
    private final String passvalue[]={"0","1","2","3","4","5","6","7","8","9"};//don't change
    public DataHandler() {
        
    }
   
    public DataHandler(String getString) {
        this.getString = getString;
    }

    public DataHandler(int getInteger) {
        this.getInteger = getInteger;
    }

    public DataHandler(char[] getchar) {
        this.getchar = getchar;
    }

    public DataHandler(String getString, int getInteger, char[] getchar) {
        this.getString = getString;
        this.getInteger = getInteger;
        this.getchar = getchar;
    }
    
    /*
     * process Data Types
     */
    public char[]  getCharArray(){
        
        char ch[]=new char[getString.length()];
        
        for(int i=0;i<getString.length();i++){
            ch[i]=getString.charAt(i);
        }
        return ch;
    }
    public char[]  getCharArray(String getString){
        char ch[]=new char[getString.length()];
        
        for(int i=0;i<getString.length();i++){
            ch[i]=getString.charAt(i);
        }
        return ch;
    }
     public char[]  setAndgetCharArray(String setAndgetString){
        this.getString=getString;
        
        char ch[]=new char[getString.length()];
        
        for(int i=0;i<getString.length();i++){
            ch[i]=getString.charAt(i);
        }
        return ch;
    }
    
    public int[]  getIntegerArray(){
        
        int intergerNumber=getInteger<0?-getInteger:getInteger;
       
        int x=intergerNumber;
        int count=0;
        while(x!=0){
           x=x/10;
           count++;
           
        }
        int interger[]=new int[count];
        int z=intergerNumber;
        
        for(int i=0;i<count;i++){
          int k=z%10;
          z=z/10; 
          interger[count-(i+1)]=k;
        }
        return interger;
        
    }
    public String getString(char getArray[]){
        String passString=null;
        char ch[]=getArray;
        
        for(int i=0;i<ch.length;i++){
           passString+=ch[i];
        }        
        return passString; 
    }
    public String getString(){
        String passString=null;
        char ch[]=getchar;
        
        for(int i=0;i<ch.length;i++){
           passString+=ch[i];
        }        
        return passString;
    }
    public String getEntripPassword(char ch[]){
        NumberFormat nf= NumberFormat.getInstance();
        nf.setMinimumIntegerDigits(3);
        String entripPassword="";
        for(char charater:ch){
            int value=charater;
            entripPassword+=nf.format(value);
        }
       
        for(int i=0;i<10;i++){
            entripPassword=entripPassword.replaceAll(passvalue[i], passCharat[i]);  
        }
        return entripPassword;
    }
    public String getDetripPassword(String simblepassword){
        String passToValuepassword=simblepassword;
        
        for(int i=0;i<10;i++){
            passToValuepassword=passToValuepassword.replaceAll(passCharat[i],passvalue[i]);  
        }
        int valueset[]=new int[(passToValuepassword.length()/3)];
        
        for(int j=0;j!=passToValuepassword.length();){
            
           int value=Integer.parseInt(passToValuepassword.substring(j,3+j)); 
           valueset[j/3]=value;
           j=j+3;
        }
        String detripPassword="";
        for(int charvalue:valueset){
           char ch=(char)charvalue;
           detripPassword+=ch;
        }
        return detripPassword;
    }
    public byte[] createImageByteArraya(String filePath,String fileType) throws IOException{
        //read image and get byte array
            File file=new File(filePath);
            BufferedImage image=ImageIO.read(file);
            ByteArrayOutputStream baos=new ByteArrayOutputStream();
            
            ImageIO.write(image,fileType, baos);
            byte[] res=baos.toByteArray();
            baos.close();
            baos.flush();
            return res;
    }
    public boolean ByteArrayToImageAndSaveImageFile(String saveFilePath_Name_FileType,String saveFileTypeAndByteArrayFileType,byte res[]) throws IOException{
         //write Image to file
            ByteArrayInputStream bais=new ByteArrayInputStream(res);
           
            Iterator<?> reades=ImageIO.getImageReadersByFormatName(saveFileTypeAndByteArrayFileType);
            ImageReader imageReader=(ImageReader) reades.next();
            Object sObject=bais;
            ImageInputStream iis=ImageIO.createImageInputStream(sObject);
            imageReader.setInput(iis, true);
            ImageReadParam readParam=imageReader.getDefaultReadParam();
            
            Image image1=imageReader.read(0, readParam);
            
            BufferedImage bufferedImage=new BufferedImage(image1.getWidth(null), image1.getHeight(null), BufferedImage.TYPE_INT_RGB);
            
            bais.close();
            
            Graphics2D graphics2D=bufferedImage.createGraphics();
            graphics2D.drawImage(image1, null, null);
            
            File writeImage=new File(saveFilePath_Name_FileType);
            
            return ImageIO.write(bufferedImage,saveFileTypeAndByteArrayFileType, writeImage);
            
    }
    public String getFileType(String filepath){
        Pattern pattern= Pattern.compile("[.]");
        Matcher matcher=pattern.matcher(filepath);
        String fileType="";
        while(matcher.find()){
            fileType=filepath.substring(matcher.start()+1, filepath.length());
        }
        return fileType;
    }
    public String[] getFileTypePath(String filepath){
        Pattern pattern= Pattern.compile("[.]");
        Matcher matcher=pattern.matcher(filepath);
        String fileType="";
        while(matcher.find()){
            fileType=filepath.substring(matcher.start()+1, filepath.length());
        }
        String passArray[]=new String[2];
        passArray[0]=filepath;
        passArray[1]=fileType;
        // first eliment path secoend type
        return passArray;
    }
    public byte[] createFilesToByte(String filePathWithFileType) throws FileNotFoundException, IOException{
         File file=new File(filePathWithFileType);
         
         FileInputStream fis=new FileInputStream(file);
         
         ByteArrayOutputStream baos=new ByteArrayOutputStream();
         
         byte []arrayByte=new byte[2048];
         
         for(int readNum;(readNum=fis.read(arrayByte))!= -1;){
                baos.write(arrayByte,0, readNum);
               
         }
        
        byte []bytes=baos.toByteArray();
       
        return bytes;
    }
    
    public boolean byteArrayToSaveFile(byte []getByteArray,String filePathWithFileType) throws FileNotFoundException, IOException{
        File file=new File(filePathWithFileType);
        FileOutputStream fileOutputStream=new FileOutputStream(file);
        fileOutputStream.write(getByteArray);
        fileOutputStream.flush();
        fileOutputStream.close();
        return file.isFile();
    }
    public int[] getRandomQuetionNumbers(int quetionNumberCount,int maximumOuetions ){
         Random random=new Random();
        int numberCount=quetionNumberCount;
        int max_Quetions=maximumOuetions;
        int []list_Quetions=new int[numberCount];
        
        for(int i=0;i<numberCount;){
            int new_number=random.nextInt(max_Quetions)+1;
            if(isAvalibleNumberInArray(list_Quetions, new_number)==false){
                list_Quetions[i]=new_number;
                i++; 
            }
            
        }
        int []sortArray=sortArray(list_Quetions);
        return sortArray;
    }
    public boolean isAvalibleNumberInArray(int []list_Quetions,int new_number){
         boolean isTrue=false;
        for(int i=0;i<list_Quetions.length;i++){
            if(list_Quetions[i]==new_number){
                isTrue=true;
                break;
            }
        }
        return isTrue;
    }
    public int[] sortArray(int []list_Quitions){
       for(int i=list_Quitions.length;i>0;i--){ 
           
            int max=list_Quitions[0];
            int index=0;

            for(int j=1;j<i;j++){
                if(list_Quitions[j]>max){
                    max=list_Quitions[j];
                    index=j;
                }
            }
            list_Quitions[index]=list_Quitions[i-1];
	    list_Quitions[i-1]=max;
       }
       return list_Quitions;  
    }
    public String getFileName(String nameType){
        Pattern pattern= Pattern.compile("[.]");
        Matcher matcher=pattern.matcher(nameType);
        String nameTypes="";
        while(matcher.find()){
            nameTypes=nameType.substring(0, matcher.start());
        }
        return nameTypes;
    }
}

