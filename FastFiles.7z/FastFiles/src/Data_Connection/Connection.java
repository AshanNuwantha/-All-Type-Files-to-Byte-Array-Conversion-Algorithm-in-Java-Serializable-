/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Data_Connection;

import java.io.File;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.filechooser.FileNameExtensionFilter;



/**
 *
 * @author Ashan Dassanayake
 */

public class Connection {
    private String pathFile;
    private String fileNameType;
    private long fileByteSize;
    public Connection() {
    }
    
    public boolean openFileChooser(JFrame frame ){
       JFileChooser chooser = new JFileChooser();
        FileNameExtensionFilter ff = new FileNameExtensionFilter("","*.*");
        chooser.setFileFilter(ff);
        int result = chooser.showOpenDialog(frame);
        if(result == JFileChooser.APPROVE_OPTION){
            File selectedFile = chooser.getSelectedFile();
            
            pathFile=selectedFile.getPath();
            fileNameType=selectedFile.getName();
            fileByteSize=selectedFile.length();
            
            selectedFile.exists();
            return true;
          
        }else{
            return false;
        }
    }
    public String fileSizeConvater(long length){
         double sizeKB=(length/1024);
         double sizeMB=sizeKB/1024;
         double sizeGB=sizeMB/1024;
         double sizeTB=sizeGB/1024;
         double sizePB=sizeGB/1024;
       
        
        if(sizeMB<1){
            return String.format("%.2f",sizeKB)+"KB";
        }else if((sizeMB>=1)&&(sizeGB<1)){
            return String.format("%.2f",sizeMB)+"MB";
        }else if((sizeGB>=1)&&(sizeTB<1)){
           return String.format("%.2f", sizeGB)+"GB";
        }else if((sizeTB>=1)&&(sizePB<1)){
            return String.format("%.2f",sizeTB)+"TB";
        }else if(sizePB>1) {
            return String.format("%.2f",sizePB)+"PB";
        }else{
            return "";
        }
        
    }
    public boolean fileDetailsCheck(){
        if((pathFile!=null)&&(fileNameType!=null)&&(fileByteSize>0)&&(pathFile.equals(""))&&(fileNameType.equals(""))){
            return true;
        }else{
            return false;
        }
    }
    public long getFileByteSize() {
        return fileByteSize;
    }

    public void setFileByteSize(long fileByteSize) {
        this.fileByteSize = fileByteSize;
    }

    public String getFileNameType() {
        return fileNameType;
    }

    public void setFileNameType(String fileNameType) {
        this.fileNameType = fileNameType;
    }

    public String getPathFile() {
        return pathFile;
    }

    public void setPathFile(String pathFile) {
        this.pathFile = pathFile;
    }
    
}
